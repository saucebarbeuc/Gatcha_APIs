package com.imt.demo.dto;

public enum Brand {
    
    BMW,
    MERCEDES
    
}
